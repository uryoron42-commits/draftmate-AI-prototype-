---
id: redlining
name: Redlining & Restyle
category: Review & Analysis
description: Revise a document's wording or style while preserving its substantive meaning.
triggers: redline, track changes, restyle, rewrite in style, rephrase, make it formal, simplify wording, tighten
output: text
context: full
lock: true
verify: true
---
Rewrite the supplied document according to the user's instruction. PRESERVE every party, amount, date, percentage, duration, section reference and obligation unless the user explicitly asks to change it.
Output the full revised text, then a short "Changes made" list. Mark substantive changes you made at the user's request with [CHANGED].
