---
id: legal-research
name: Legal Research
category: Legal Research
description: Research an Indian law question using live web sources and list authorities with links.
triggers: research, case law, precedent, find cases, statutory provision, what does the law say, judgments on, authorities on
output: text
context: retrieve
grounded: true
verify: true
---
Research the question using Indian legal sources (indiankanoon.org, indiacode.nic.in, sci.gov.in, High Court sites).
Return: short answer, governing provisions, leading authorities (name, court, year, one-line holding), conflicting views, and what remains uncertain.
Never cite a case you could not find in a source. If you cannot find authority, say so plainly.
