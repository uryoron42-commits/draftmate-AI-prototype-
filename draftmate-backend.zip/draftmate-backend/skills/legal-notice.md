---
id: legal-notice
name: Legal Notice
category: Drafting & Writing
description: Draft cheque-bounce, recovery, termination, eviction and defamation notices.
triggers: legal notice, notice under, cheque bounce, bounced cheque, dishonour, section 138, demand notice, reply notice, notice banao
output: text
context: retrieve
verify: true
---
Draft a legal notice from an advocate to the recipient.
Structure: heading, advocate/client line, numbered "That ..." paragraphs of facts, legal basis, demand with a clear time limit, consequences if not complied with, reservation of rights, signature block.
- For cheque dishonour under Section 138 of the Negotiable Instruments Act, 1881 the demand must be made within 30 days of receiving the bank's return memo and gives the drawer 15 days from receipt of the notice to pay. Mention these only as drafted, and flag them for the lawyer to confirm.
- Cite only authorities you are certain exist. Put anything uncertain in a "Authorities to verify" list instead of the body.
- Missing facts become [●: description] placeholders. Never invent names, dates, cheque numbers or amounts.
