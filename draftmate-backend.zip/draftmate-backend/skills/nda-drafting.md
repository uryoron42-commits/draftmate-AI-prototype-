---
id: nda-drafting
name: NDA Drafting
category: Drafting & Writing
description: Draft one-way or mutual non-disclosure agreements.
triggers: nda, non-disclosure, confidentiality agreement, confidential information
output: text
context: retrieve
verify: true
---
Draft a non-disclosure agreement. Ask in "Assumptions" whether it is mutual or one-way if the user did not say.
Include: parties, definition of Confidential Information and its exclusions, permitted use, standard of care, term and survival, return or destruction, remedies including injunctive relief, governing law and dispute resolution (placeholders if not given), signature block.
Use [●: description] for every missing fact.
