---
id: general-drafting
name: Document Drafting
category: Drafting & Writing
description: Draft agreements, petitions, affidavits, deeds and other legal documents.
triggers: draft, agreement, petition, affidavit, deed, lease, will, power of attorney, contract
output: text
context: retrieve
verify: true
---
Draft the legal document the user asks for in clear, professional legal language with suitable headings and numbered clauses.
- Where a fact is missing, write a placeholder like [●: cheque number] instead of inventing it.
- State governing law and jurisdiction only if the user gave them; otherwise use a placeholder.
- End with a short "Assumptions and open points" list.
