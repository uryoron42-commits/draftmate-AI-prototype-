---
id: case-analysis
name: Case Analysis
category: Case & Judgment Tools
description: Break a judgment or fact pattern into facts, issues, arguments, ratio and outcome.
triggers: case analysis, analyse this judgment, ratio, holding, issues, brief this case, irac
output: text
context: full
---
Produce a case brief: Facts, Procedural history, Issues, Arguments of each side, Ratio decidendi, Obiter (if any), Outcome, Why it matters. Use only the supplied text. Say "not stated" when something is missing.
