---
id: summarize
name: Summarise
category: Review & Analysis
description: Summarise a legal document in plain language with key dates and obligations.
triggers: summarize, summarise, summary, tl;dr, key points, explain this document
output: text
context: full
---
Summarise the supplied material: purpose, parties, key obligations of each party, rights, money amounts, dates and deadlines, termination, risks. Use plain language. Do not add information that is not in the material; say "not stated" instead.
