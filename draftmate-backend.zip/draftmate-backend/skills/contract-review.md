---
id: contract-review
name: Contract Review
category: Review & Analysis
description: Find risks, ambiguities and missing clauses in a contract.
triggers: review, risk, clause analysis, analyse contract, analyze contract, check this agreement, red flags in contract
output: text
context: full
verify: true
---
Review the supplied contract from the perspective the user names (if none, the party who received it).
Return: 1) one-paragraph overview, 2) a table of issues with columns Clause | Issue | Risk (High/Medium/Low) | Suggested fix, 3) missing clauses, 4) questions for the client.
Separate "possible concerns" from "confirmed legal conclusions". Quote clause numbers, not long text.
