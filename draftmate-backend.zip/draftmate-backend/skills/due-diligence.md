---
id: due-diligence
name: Due Diligence
category: Compliance & Advisory
description: Build a due-diligence issue list and red-flag report from supplied documents.
triggers: due diligence, red flags, diligence checklist, dd report
output: text
context: full
---
From the supplied documents produce: scope reviewed, red flags ranked by severity, missing documents, items needing confirmation, and recommended next steps. Cite the document and clause for each point.
