import os
import re
from io import BytesIO
from xml.sax.saxutils import escape

from reportlab.lib import colors
from reportlab.lib.enums import TA_CENTER
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet
from reportlab.lib.units import mm
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.platypus import HRFlowable, PageBreak, Paragraph, SimpleDocTemplate, Spacer, Table, TableStyle

# Helvetica has no rupee sign. Use a Unicode font when one is installed, else fall back to "Rs."
_FONTS = [os.getenv("PDF_FONT_PATH", ""), "C:/Windows/Fonts/arial.ttf", "C:/Windows/Fonts/segoeui.ttf",
          "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf", "/Library/Fonts/Arial Unicode.ttf", "/System/Library/Fonts/Supplemental/Arial.ttf"]
_BOLDS = ["C:/Windows/Fonts/arialbd.ttf", "C:/Windows/Fonts/segoeuib.ttf", "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf",
          "/System/Library/Fonts/Supplemental/Arial Bold.ttf"]
BODY, BOLD, UNICODE = "Helvetica", "Helvetica-Bold", False
for _p in _FONTS:
    if _p and os.path.exists(_p):
        try:
            pdfmetrics.registerFont(TTFont("DM", _p))
            BODY = BOLD = "DM"
            for _b in _BOLDS:
                if os.path.exists(_b):
                    pdfmetrics.registerFont(TTFont("DM-B", _b)); BOLD = "DM-B"; break
            pdfmetrics.registerFontFamily("DM", normal="DM", bold=BOLD, italic="DM", boldItalic=BOLD)
            UNICODE = True
            break
        except Exception:  # noqa
            pass

STATUS = {"verified": ("Verified", "#12803C"), "partial": ("Partially verified", "#B26A00"), "outdated": ("Outdated law", "#7A3FD0"),
          "unverified": ("Unverified", "#C62839"), "unchecked": ("Not checked", "#64748B")}


def _inline(s):
    s = escape(s)
    s = re.sub(r"\*\*(.+?)\*\*", r"<b>\1</b>", s)
    return re.sub(r"(?<![\*\w])\*(?!\s)(.+?)(?<!\s)\*(?![\*\w])", r"<i>\1</i>", s)


def generate_pdf(title, content, verification=None):
    if not UNICODE:
        content, title = content.replace("₹", "Rs. "), title.replace("₹", "Rs. ")
    buf = BytesIO()
    doc = SimpleDocTemplate(buf, pagesize=A4, rightMargin=22 * mm, leftMargin=22 * mm, topMargin=22 * mm, bottomMargin=22 * mm,
                            title=title, author="DraftMate AI")
    st = getSampleStyleSheet()
    navy = colors.HexColor("#243B64")
    title_s = ParagraphStyle("T", parent=st["Title"], fontName=BOLD, fontSize=19, leading=24, alignment=TA_CENTER, textColor=navy, spaceAfter=8 * mm)
    head_s = ParagraphStyle("H", parent=st["Heading2"], fontName=BOLD, fontSize=12, leading=16, textColor=navy, spaceBefore=5 * mm, spaceAfter=2 * mm, keepWithNext=True)
    body_s = ParagraphStyle("B", parent=st["BodyText"], fontName=BODY, fontSize=10, leading=15, spaceAfter=3 * mm, splitLongWords=True)
    bullet_s = ParagraphStyle("L", parent=body_s, leftIndent=6 * mm, bulletIndent=1 * mm, spaceAfter=1.5 * mm)
    small = ParagraphStyle("S", parent=body_s, fontSize=8.5, leading=11, spaceAfter=0)

    story = [Paragraph(escape(title), title_s), HRFlowable(width="100%", thickness=1, color=colors.HexColor("#CBD5E1")), Spacer(1, 5 * mm)]
    for line in content.splitlines():
        line = line.strip()
        if not line:
            story.append(Spacer(1, 2 * mm)); continue
        if re.match(r"^#{1,4}\s", line):
            story.append(Paragraph(_inline(line.lstrip("#").strip()), head_s))
        elif re.match(r"^[-*•]\s+", line):
            story.append(Paragraph(_inline(re.sub(r"^[-*•]\s+", "", line)), bullet_s, bulletText="•"))
        elif len(line) < 100 and (line.isupper() or (line[:1].isdigit() and (". " in line[:5] or ") " in line[:5]))):
            story.append(Paragraph(_inline(line), head_s))
        else:
            story.append(Paragraph(_inline(line), body_s))

    if verification and verification.get("citations"):
        story += [PageBreak(), Paragraph("Verification Certificate", title_s)]
        c = verification["counts"]
        score = verification.get("trust_score")
        story.append(Paragraph(f"Authorities checked: {verification['total']}. Verified {c['verified']}, partial {c['partial']}, outdated {c['outdated']}, "
                               f"unverified {c['unverified']}." + (f" Trust score: {score}/100." if score is not None else ""), body_s))
        rows = [[Paragraph("<b>Authority</b>", small), Paragraph("<b>Status</b>", small), Paragraph("<b>Notes and sources</b>", small)]]
        for r in verification["citations"]:
            label, col = STATUS.get(r["status"], STATUS["unchecked"])
            src = "; ".join(s["title"] or s["uri"] for s in r.get("sources", [])[:2])
            note = r.get("note", "") + (f" Suggested: {r['replacement']}." if r.get("replacement") else "") + (f" Sources: {src}" if src else "")
            rows.append([Paragraph(escape(r["raw"]), small), Paragraph(f'<font color="{col}"><b>{label}</b></font>', small), Paragraph(escape(note.strip()), small)])
        t = Table(rows, colWidths=[62 * mm, 28 * mm, 80 * mm], repeatRows=1)
        t.setStyle(TableStyle([("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#E8EEF8")), ("GRID", (0, 0), (-1, -1), 0.4, colors.HexColor("#CBD5E1")),
                               ("VALIGN", (0, 0), (-1, -1), "TOP"), ("TOPPADDING", (0, 0), (-1, -1), 4), ("BOTTOMPADDING", (0, 0), (-1, -1), 4)]))
        story += [t, Spacer(1, 8 * mm), Paragraph("AI-assisted draft. Reviewed by: ______________________   Date: ____________", body_s)]

    def footer(canvas, d):
        canvas.saveState()
        canvas.setStrokeColor(colors.HexColor("#CBD5E1")); canvas.line(22 * mm, 15 * mm, A4[0] - 22 * mm, 15 * mm)
        canvas.setFont(BODY, 8); canvas.setFillColor(colors.HexColor("#64748B"))
        canvas.drawString(22 * mm, 10 * mm, "Generated with DraftMate AI. AI-assisted: requires review by a qualified lawyer.")
        canvas.drawRightString(A4[0] - 22 * mm, 10 * mm, f"Page {d.page}")
        canvas.restoreState()

    doc.build(story, onFirstPage=footer, onLaterPages=footer)
    return buf.getvalue()
